﻿namespace Projeto2025.Forms
{
    partial class SelectorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnDeckBuilder = new Button();
            btnCartaAleatoria = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // btnDeckBuilder
            // 
            btnDeckBuilder.Location = new Point(299, 130);
            btnDeckBuilder.Name = "btnDeckBuilder";
            btnDeckBuilder.Size = new Size(183, 29);
            btnDeckBuilder.TabIndex = 0;
            btnDeckBuilder.Text = "Deck Builder";
            btnDeckBuilder.UseVisualStyleBackColor = true;
            btnDeckBuilder.Click += btnDeckBuilder_Click;
            // 
            // btnCartaAleatoria
            // 
            btnCartaAleatoria.Location = new Point(299, 165);
            btnCartaAleatoria.Name = "btnCartaAleatoria";
            btnCartaAleatoria.Size = new Size(183, 29);
            btnCartaAleatoria.TabIndex = 1;
            btnCartaAleatoria.Text = "Carta Aleatória";
            btnCartaAleatoria.UseVisualStyleBackColor = true;
            btnCartaAleatoria.Click += btnCartaAleatoria_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(299, 200);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(183, 29);
            btnSair.TabIndex = 2;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // SelectorForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSair);
            Controls.Add(btnCartaAleatoria);
            Controls.Add(btnDeckBuilder);
            Name = "SelectorForm";
            Text = "SelectorForm";
            ResumeLayout(false);
        }

        #endregion

        private Button btnDeckBuilder;
        private Button btnCartaAleatoria;
        private Button btnSair;
    }
}