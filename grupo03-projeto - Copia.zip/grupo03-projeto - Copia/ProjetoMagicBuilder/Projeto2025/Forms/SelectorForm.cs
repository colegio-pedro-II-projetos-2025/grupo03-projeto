﻿using Projeto2025.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto2025.Forms
{
    public partial class SelectorForm : Form
    {
        private Usuario usuarioLogado { get; set; }
        internal void ReceberUsuario(Usuario usuario)
        {
            usuarioLogado = usuario;
        }
        public SelectorForm()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCartaAleatoria_Click(object sender, EventArgs e)
        {
            CartaAleatoriaForm cartaAleatoriaForm = new CartaAleatoriaForm();
            cartaAleatoriaForm.Show();
            cartaAleatoriaForm.ReceberUsuario(usuarioLogado);
        }

        private void btnDeckBuilder_Click(object sender, EventArgs e)
        {
            DeckBuilderForm deckBuilderForm = new DeckBuilderForm();
            deckBuilderForm.Show();
            deckBuilderForm.ReceberUsuario(usuarioLogado);
        }
    }
}
