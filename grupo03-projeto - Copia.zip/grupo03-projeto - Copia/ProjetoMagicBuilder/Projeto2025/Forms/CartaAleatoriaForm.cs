﻿using Projeto2025.Entity;
using Projeto2025.Repository;
using Projeto2025.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto2025.Forms
{
    public partial class CartaAleatoriaForm : Form
    {
        private Usuario usuarioLogado { get; set; }
        private List<Carta> cartas = new List<Carta>();
        private Carta atual;
        private int acertos, tentativas;
        internal void ReceberUsuario(Usuario usuario)
        {
            usuarioLogado = usuario;
        }
        public CartaAleatoriaForm()
        {
            InitializeComponent();
        }

        private void CartaAleatoriaForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tentativa = tbNome.Text;
            if (tentativa == atual.Nome) acertos++;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var cartaRepo = new CartaRepository(RepositoryUtil.ConnectionString);
            cartas = cartaRepo.ObterTodasCartas();
            Random pos = new Random();
            int loc = pos.Next(1, 290);
            atual = cartas[loc];
            lblDescricao.Text = atual.Descricao;
            tentativas++;
        }
        private void btnParar_Click(object sender, EventArgs e)
        {
            if 
        }
    }
}
