﻿namespace Projeto2025.Forms
{
    partial class CartaAleatoriaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblDescricao = new Label();
            btnEnviar = new Button();
            btnComecar = new Button();
            tbNome = new TextBox();
            lblStatus = new Label();
            btnParar = new Button();
            SuspendLayout();
            // 
            // lblDescricao
            // 
            lblDescricao.AutoSize = true;
            lblDescricao.Location = new Point(270, 153);
            lblDescricao.MaximumSize = new Size(300, 0);
            lblDescricao.Name = "lblDescricao";
            lblDescricao.Size = new Size(50, 20);
            lblDescricao.TabIndex = 0;
            lblDescricao.Text = "label1";
            // 
            // btnEnviar
            // 
            btnEnviar.Location = new Point(401, 187);
            btnEnviar.Name = "btnEnviar";
            btnEnviar.Size = new Size(94, 29);
            btnEnviar.TabIndex = 1;
            btnEnviar.Text = "button1";
            btnEnviar.UseVisualStyleBackColor = true;
            btnEnviar.Click += button1_Click;
            // 
            // btnComecar
            // 
            btnComecar.Location = new Point(401, 242);
            btnComecar.Name = "btnComecar";
            btnComecar.Size = new Size(94, 29);
            btnComecar.TabIndex = 2;
            btnComecar.Text = "button2";
            btnComecar.UseVisualStyleBackColor = true;
            btnComecar.Click += button2_Click;
            // 
            // tbNome
            // 
            tbNome.Location = new Point(270, 189);
            tbNome.Name = "tbNome";
            tbNome.Size = new Size(125, 27);
            tbNome.TabIndex = 3;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(345, 251);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(50, 20);
            lblStatus.TabIndex = 4;
            lblStatus.Text = "label2";
            // 
            // btnParar
            // 
            btnParar.Location = new Point(401, 297);
            btnParar.Name = "btnParar";
            btnParar.Size = new Size(94, 29);
            btnParar.TabIndex = 5;
            btnParar.Text = "button1";
            btnParar.UseVisualStyleBackColor = true;
            btnParar.Click += btnParar_Click;
            // 
            // CartaAleatoriaForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(754, 480);
            Controls.Add(btnParar);
            Controls.Add(lblStatus);
            Controls.Add(tbNome);
            Controls.Add(btnComecar);
            Controls.Add(btnEnviar);
            Controls.Add(lblDescricao);
            Margin = new Padding(3, 4, 3, 4);
            Name = "CartaAleatoriaForm";
            Text = "Carta Aleatória";
            Load += CartaAleatoriaForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblDescricao;
        private Button btnEnviar;
        private Button btnComecar;
        private TextBox tbNome;
        private Label lblStatus;
        private Button btnParar;
    }
}