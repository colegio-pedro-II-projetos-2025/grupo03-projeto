﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto2025.Entity
{
    internal class Deck
    {

        public int ID { get; set; }
        public string Dono { get; set; }
        public string Nome { get; set; }
    }
}
