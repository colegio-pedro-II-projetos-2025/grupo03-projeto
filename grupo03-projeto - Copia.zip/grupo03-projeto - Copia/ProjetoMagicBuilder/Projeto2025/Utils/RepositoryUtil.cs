﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto2025.Utils
{
    internal class RepositoryUtil
    {
        public static string ConnectionString { get; } = "server=localhost;database=magic_bd;uid=root;pwd=;";
    }
}
