# grupo03-projeto
# Nome do Projeto
> Breve descrição do projeto. Explique o que ele faz e qual é seu propósito.

---

## 👥 Participantes

- Gabriel Fernandes
- Gabriel Faleiro
- Ian
- Ana Clara

---

## 🏫 Turma
- DS311
- 3º ano – Desenvolvimento de Sistemas  
- Colégio Pedro II – Campus São Cristóvão III
